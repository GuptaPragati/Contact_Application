package com.example.contactapplication.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.example.contactapplication.model.Contact;
import com.example.contactapplication.params.Params;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    public DatabaseHandler(Context context) {
        super(context, Params.DB_NAME, null, Params.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
    String create= "CREATE TABLE "+Params.TABLE_NAME+"("+
            Params.KEY_ID+" INTEGER PRIMARY KEY,"+Params.NAME+" TEXT,"+
            Params.PHONE_NUMBER+" TEXT"+")";
        Log.d("message to create query","query has been created"+create);
        sqLiteDatabase.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void writeContactsToDb(Contact contact)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(Params.NAME,contact.getName());
        contentValues.put(Params.PHONE_NUMBER,contact.getPhoneNum());
        sqLiteDatabase.insert(Params.TABLE_NAME,null,contentValues);
        Log.d("Success","Successfully inserted");
        sqLiteDatabase.close();
    }
    public List<Contact> readContactsFromDb()
    {
        List<Contact> contactList=new ArrayList<>();
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        String selectQuery="SELECT * FROM "+Params.TABLE_NAME;
        Cursor cursor=sqLiteDatabase.rawQuery(selectQuery,null);
        int count=cursor.getCount();
        Log.d("Number of rows in DB","Total rows in DB is: "+count);
        cursor.moveToFirst();
            do {
                Contact contact = new Contact();
                contact.setId(cursor.getInt(0));
                contact.setName(cursor.getString(1));
                contact.setPhoneNum(cursor.getString(2));
                contactList.add(contact);
            }
            while (cursor.moveToNext());
        return contactList;
    }
    public int updateContactsToDb(Contact contact)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(Params.NAME,contact.getName());
        contentValues.put(Params.PHONE_NUMBER,contact.getPhoneNum());
        int status= sqLiteDatabase.update(Params.TABLE_NAME,contentValues,Params.KEY_ID + "=?",new String[]{String.valueOf(contact.getId())});
        return status;
    }
    public void deleteFromContactDb(int id)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        sqLiteDatabase.delete(Params.TABLE_NAME,Params.KEY_ID+"=?",new String[]{String.valueOf(id)});
    }

}
