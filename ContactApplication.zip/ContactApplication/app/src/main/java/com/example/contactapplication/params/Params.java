package com.example.contactapplication.params;

public class Params {
    public static final int DB_VERSION=1;
    public static final String DB_NAME="contactsDb";
    public static final String TABLE_NAME="contact_table";
    //attributes of tables
    public static String KEY_ID="unique_id";
    public static final String NAME="person_name";
    public static final String PHONE_NUMBER="phone_no";
}
