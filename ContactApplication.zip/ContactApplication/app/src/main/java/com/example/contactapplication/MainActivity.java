package com.example.contactapplication;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.example.contactapplication.data.DatabaseHandler;
import com.example.contactapplication.model.Contact;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
        ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DatabaseHandler databaseHandler=new DatabaseHandler(getApplicationContext());
        SQLiteDatabase sqLiteDatabase=databaseHandler.getReadableDatabase();
        Contact contact=new Contact();
        contact.setPhoneNum("9092364720");
        contact.setName("happy");
        databaseHandler.writeContactsToDb(contact);
        Contact contact1=new Contact();
        contact1.setPhoneNum("9098764720");
        contact1.setName("pragati");
        databaseHandler.writeContactsToDb(contact1);
        Contact contact2=new Contact();
        contact2.setPhoneNum("9092309720");
        contact2.setName("Gupta");
        databaseHandler.writeContactsToDb(contact2);
        contact2.setId(3);
        contact2.setName("Sunita Gupta");
        contact2.setPhoneNum("8767867689");
        Contact contact3=new Contact();
        contact3.setName("happy Gupta");
        contact3.setPhoneNum("8767707689");
        databaseHandler.writeContactsToDb(contact3);
        int affectedRows=databaseHandler.updateContactsToDb(contact2);
        databaseHandler.deleteFromContactDb(1);
        Log.d("updated contacts","Affected rows are: "+affectedRows);
        List<Contact> allContacts=databaseHandler.readContactsFromDb();
        List<String> contactView=new ArrayList<>();
        for (Contact con:allContacts
             ) {
            Log.d("All contacts","contacts are: "+"\n"+con.getId()+"\n"+con.getName()+"\n"+con.getPhoneNum());
            contactView.add(con.getName()+" ("+con.getPhoneNum()+")");
        }
        listView=findViewById(R.id.listview);
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,contactView);
        listView.setAdapter(arrayAdapter);
    }
}
