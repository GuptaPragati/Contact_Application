package com.example.contactapplication.model;

import lombok.*;

@NoArgsConstructor
public class Contact {
    @Setter @Getter
    private int id;
    @Setter @Getter
    private String name;
    @Setter @Getter
    private String phoneNum;
    public Contact(String name,String phoneNum)
    {
        setName(name);
        setPhoneNum(phoneNum);
    }
    public Contact(int id,String name,String phoneNum)
    {
        setId(id);
        setName(name);
        setPhoneNum(phoneNum);
    }
}
